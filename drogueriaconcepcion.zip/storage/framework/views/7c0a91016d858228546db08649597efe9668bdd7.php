<?php $__env->startSection('content'); ?>
    <h3 class="page-title"><?php echo app('translator')->getFromJson('quickadmin.itemsoc.title'); ?></h3>
    <?php echo Form::open(['method' => 'POST', 'route' => ['itemsocs.store']]); ?>


    <div class="panel panel-default">
        <div class="panel-heading">
            <?php echo app('translator')->getFromJson('quickadmin.qa_create'); ?>
        </div>
        
        <div class="panel-body">
            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('folio_id', 'Folio OC', ['class' => 'control-label']); ?>

                    <?php if(isset($id)): ?>
                        <?php echo Form::select('folio_id', $folios, $id, ['class' => 'form-control select2']); ?>

                    <?php else: ?>
                        <?php echo Form::select('folio_id', $folios, old('folio_id'), ['class' => 'form-control select2']); ?>

                    <?php endif; ?> 
                    <p class="help-block"></p>
                    <?php if($errors->has('folio_id')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('folio_id')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('producto_id', 'Producto', ['class' => 'control-label']); ?>

                    <?php echo Form::select('producto_id', $productos, old('producto_id'), ['class' => 'form-control select2']); ?>

                    <p class="help-block"></p>
                    <?php if($errors->has('producto_id')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('producto_id')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('presentancion_id', 'Presentanción', ['class' => 'control-label']); ?>

                    <?php echo Form::select('presentancion_id', $presentancions, old('presentancion_id'), ['class' => 'form-control select2']); ?>

                    <p class="help-block"></p>
                    <?php if($errors->has('presentancion_id')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('presentancion_id')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('cantidad', 'Cantidad', ['class' => 'control-label']); ?>

                    <?php echo Form::number('cantidad', old('cantidad'), ['class' => 'form-control', 'placeholder' => '']); ?>

                    <p class="help-block"></p>
                    <?php if($errors->has('cantidad')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('cantidad')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('precio_unidad', 'Precio unidad', ['class' => 'control-label']); ?>

                    <?php echo Form::text('precio_unidad', old('precio_unidad'), ['class' => 'form-control', 'placeholder' => '']); ?>

                    <p class="help-block"></p>
                    <?php if($errors->has('precio_unidad')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('precio_unidad')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('observaciones', 'Observaciones', ['class' => 'control-label']); ?>

                    <?php echo Form::textarea('observaciones', old('observaciones'), ['class' => 'form-control ', 'placeholder' => '']); ?>

                    <p class="help-block"></p>
                    <?php if($errors->has('observaciones')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('observaciones')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            
        </div>
    </div>

    <?php echo Form::submit(trans('quickadmin.qa_save'), ['class' => 'btn btn-danger']); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>