<?php $__env->startSection('content'); ?>
    <h3 class="page-title"><?php echo app('translator')->getFromJson('quickadmin.itemsoc.title'); ?></h3>

    <div class="panel panel-default">
        <div class="panel-heading">
            <?php echo app('translator')->getFromJson('quickadmin.qa_view'); ?>
        </div>

        <div class="panel-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th><?php echo app('translator')->getFromJson('quickadmin.itemsoc.fields.folio'); ?></th>
                            <td><?php echo e(isset($itemsoc->folio->folio) ? $itemsoc->folio->folio : ''); ?></td>
                        </tr>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('quickadmin.itemsoc.fields.producto'); ?></th>
                            <td><?php echo e(isset($itemsoc->producto->nombre) ? $itemsoc->producto->nombre : ''); ?></td>
                        </tr>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('quickadmin.itemsoc.fields.presentancion'); ?></th>
                            <td><?php echo e(isset($itemsoc->presentancion->nombre) ? $itemsoc->presentancion->nombre : ''); ?></td>
                        </tr>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('quickadmin.itemsoc.fields.cantidad'); ?></th>
                            <td><?php echo e($itemsoc->cantidad); ?></td>
                        </tr>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('quickadmin.itemsoc.fields.precio-unidad'); ?></th>
                            <td><?php echo e($itemsoc->precio_unidad); ?></td>
                        </tr>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('quickadmin.itemsoc.fields.observaciones'); ?></th>
                            <td><?php echo $itemsoc->observaciones; ?></td>
                        </tr>
                    </table>
                </div>
            </div>

            <p>&nbsp;</p>

            <a href="<?php echo e(route('itemsocs.index')); ?>" class="btn btn-default"><?php echo app('translator')->getFromJson('quickadmin.qa_back_to_list'); ?></a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>