<?php $__env->startSection('content'); ?>
    <h3 class="page-title"><?php echo app('translator')->getFromJson('quickadmin.recepcionmercaderia.title'); ?></h3>
    <?php echo Form::open(['method' => 'POST', 'route' => ['recepcionmercaderias.store']]); ?>


    <div class="panel panel-default">
        <div class="panel-heading">
            <?php echo app('translator')->getFromJson('quickadmin.qa_create'); ?>
        </div>
        
        <div class="panel-body">

            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('proveedor_id', '# OC', ['class' => 'control-label']); ?>

                    <?php echo Form::select('proveedor_id', $proveedors, old('proveedor_id'), ['class' => 'form-control select2']); ?>

                    <p class="help-block"></p>
                    <?php if($errors->has('proveedor_id')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('proveedor_id')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('fecha', 'Fecha', ['class' => 'control-label']); ?>

                    <?php echo Form::text('fecha', old('fecha'), ['class' => 'form-control date', 'placeholder' => '']); ?>

                    <p class="help-block"></p>
                    <?php if($errors->has('fecha')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('fecha')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('producto_id', 'Producto', ['class' => 'control-label']); ?>

                    <?php echo Form::select('producto_id', $productos, old('producto_id'), ['class' => 'form-control select2']); ?>

                   
                    <p class="help-block"></p>
                    <?php if($errors->has('producto_id')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('producto_id')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('lote', 'Lote', ['class' => 'control-label']); ?>

                    <?php echo Form::text('lote', old('lote'), ['class' => 'form-control', 'placeholder' => '']); ?>

                    <p class="help-block"></p>
                    <?php if($errors->has('lote')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('lote')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('fecha_vencimiento', 'Fecha vencimiento', ['class' => 'control-label']); ?>

                    <?php echo Form::text('fecha_vencimiento', old('fecha_vencimiento'), ['class' => 'form-control', 'placeholder' => '']); ?>

                    <p class="help-block"></p>
                    <?php if($errors->has('fecha_vencimiento')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('fecha_vencimiento')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('cantidad', 'Cantidad', ['class' => 'control-label']); ?>

                    <?php echo Form::number('cantidad', old('cantidad'), ['class' => 'form-control', 'placeholder' => '']); ?>

                    <p class="help-block"></p>
                    <?php if($errors->has('cantidad')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('cantidad')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('precio_compra', 'Precio compra', ['class' => 'control-label']); ?>

                    <?php echo Form::number('precio_compra', old('precio_compra'), ['class' => 'form-control', 'placeholder' => '']); ?>

                    <p class="help-block"></p>
                    <?php if($errors->has('precio_compra')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('precio_compra')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            
        </div>
    </div>

    <?php echo Form::submit(trans('quickadmin.qa_save'), ['class' => 'btn btn-danger']); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    ##parent-placeholder-b6e13ad53d8ec41b034c49f131c64e99cf25207a##
    <script>
        $('.date').datepicker({
            autoclose: true,
            dateFormat: "<?php echo e(config('app.date_format_js')); ?>"
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>