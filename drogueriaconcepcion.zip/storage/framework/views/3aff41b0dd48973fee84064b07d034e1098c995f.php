<?php $__env->startSection('content'); ?>
    <h3 class="page-title"><?php echo app('translator')->getFromJson('quickadmin.producto.title'); ?></h3>

    <div class="panel panel-default">
        <div class="panel-heading">
            <?php echo app('translator')->getFromJson('quickadmin.qa_view'); ?>
        </div>

        <div class="panel-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th><?php echo app('translator')->getFromJson('quickadmin.producto.fields.nombre'); ?></th>
                            <td><?php echo e($producto->nombre); ?></td>
                        </tr>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('quickadmin.producto.fields.concentracion'); ?></th>
                            <td><?php echo e($producto->concentracion); ?></td>
                        </tr>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('quickadmin.producto.fields.precio-bodega'); ?></th>
                            <td><?php echo e($producto->precio_bodega); ?></td>
                        </tr>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('quickadmin.producto.fields.laboratorio'); ?></th>
                            <td><?php echo e(isset($producto->laboratorio->nombre) ? $producto->laboratorio->nombre : ''); ?></td>
                        </tr>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('quickadmin.producto.fields.presentacion'); ?></th>
                            <td><?php echo e(isset($producto->presentacion->nombre) ? $producto->presentacion->nombre : ''); ?></td>
                        </tr>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('quickadmin.producto.fields.unidad-envase'); ?></th>
                            <td><?php echo e($producto->unidad_envase); ?></td>
                        </tr>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('quickadmin.producto.fields.modo-uso'); ?></th>
                            <td><?php echo e(isset($producto->modo_uso->uso) ? $producto->modo_uso->uso : ''); ?></td>
                        </tr>
                    </table>
                </div>
            </div><!-- Nav tabs -->
<ul class="nav nav-tabs" role="tablist">
    
<li role="presentation" class="active"><a href="#itemsoc" aria-controls="itemsoc" role="tab" data-toggle="tab">Itemsoc</a></li>
<li role="presentation" class=""><a href="#recepcionmercaderia" aria-controls="recepcionmercaderia" role="tab" data-toggle="tab">Recepcionmercaderia</a></li>
<li role="presentation" class=""><a href="#facturas" aria-controls="facturas" role="tab" data-toggle="tab">Facturas</a></li>
</ul>

<!-- Tab panes -->
<div class="tab-content">
    
<div role="tabpanel" class="tab-pane active" id="itemsoc">
<table class="table table-bordered table-striped <?php echo e(count($itemsocs) > 0 ? 'datatable' : ''); ?>">
    <thead>
        <tr>
            <th><?php echo app('translator')->getFromJson('quickadmin.itemsoc.fields.folio'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.itemsoc.fields.producto'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.itemsoc.fields.presentancion'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.itemsoc.fields.cantidad'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.itemsoc.fields.precio-unidad'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.itemsoc.fields.observaciones'); ?></th>
                        <th>&nbsp;</th>
        </tr>
    </thead>

    <tbody>
        <?php if(count($itemsocs) > 0): ?>
            <?php $__currentLoopData = $itemsocs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemsoc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr data-entry-id="<?php echo e($itemsoc->id); ?>">
                    <td><?php echo e(isset($itemsoc->folio->folio) ? $itemsoc->folio->folio : ''); ?></td>
                                <td><?php echo e(isset($itemsoc->producto->nombre) ? $itemsoc->producto->nombre : ''); ?></td>
                                <td><?php echo e(isset($itemsoc->presentancion->nombre) ? $itemsoc->presentancion->nombre : ''); ?></td>
                                <td><?php echo e($itemsoc->cantidad); ?></td>
                                <td><?php echo e($itemsoc->precio_unidad); ?></td>
                                <td><?php echo $itemsoc->observaciones; ?></td>
                                <td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('itemsoc_view')): ?>
                                    <a href="<?php echo e(route('itemsocs.show',[$itemsoc->id])); ?>" class="btn btn-xs btn-primary"><?php echo app('translator')->getFromJson('quickadmin.qa_view'); ?></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('itemsoc_edit')): ?>
                                    <a href="<?php echo e(route('itemsocs.edit',[$itemsoc->id])); ?>" class="btn btn-xs btn-info"><?php echo app('translator')->getFromJson('quickadmin.qa_edit'); ?></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('itemsoc_delete')): ?>
                                    <?php echo Form::open(array(
                                        'style' => 'display: inline-block;',
                                        'method' => 'DELETE',
                                        'onsubmit' => "return confirm('".trans("quickadmin.qa_are_you_sure")."');",
                                        'route' => ['itemsocs.destroy', $itemsoc->id])); ?>

                                    <?php echo Form::submit(trans('quickadmin.qa_delete'), array('class' => 'btn btn-xs btn-danger')); ?>

                                    <?php echo Form::close(); ?>

                                    <?php endif; ?>
                                </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td colspan="10"><?php echo app('translator')->getFromJson('quickadmin.qa_no_entries_in_table'); ?></td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
</div>
<div role="tabpanel" class="tab-pane " id="recepcionmercaderia">
<table class="table table-bordered table-striped <?php echo e(count($recepcionmercaderias) > 0 ? 'datatable' : ''); ?>">
    <thead>
        <tr>
            <th><?php echo app('translator')->getFromJson('quickadmin.recepcionmercaderia.fields.proveedor'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.recepcionmercaderia.fields.fecha'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.recepcionmercaderia.fields.producto'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.recepcionmercaderia.fields.lote'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.recepcionmercaderia.fields.fecha-vencimiento'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.recepcionmercaderia.fields.cantidad'); ?></th>
                        <th>&nbsp;</th>
        </tr>
    </thead>

    <tbody>
        <?php if(count($recepcionmercaderias) > 0): ?>
            <?php $__currentLoopData = $recepcionmercaderias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recepcionmercaderia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr data-entry-id="<?php echo e($recepcionmercaderia->id); ?>">
                    <td><?php echo e(isset($recepcionmercaderia->proveedor->folio) ? $recepcionmercaderia->proveedor->folio : ''); ?></td>
                                <td><?php echo e($recepcionmercaderia->fecha); ?></td>
                                <td><?php echo e(isset($recepcionmercaderia->producto->nombre) ? $recepcionmercaderia->producto->nombre : ''); ?></td>
                                <td><?php echo e($recepcionmercaderia->lote); ?></td>
                                <td><?php echo e($recepcionmercaderia->fecha_vencimiento); ?></td>
                                <td><?php echo e($recepcionmercaderia->cantidad); ?></td>
                                <td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('recepcionmercaderium_view')): ?>
                                    <a href="<?php echo e(route('recepcionmercaderias.show',[$recepcionmercaderia->id])); ?>" class="btn btn-xs btn-primary"><?php echo app('translator')->getFromJson('quickadmin.qa_view'); ?></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('recepcionmercaderium_edit')): ?>
                                    <a href="<?php echo e(route('recepcionmercaderias.edit',[$recepcionmercaderia->id])); ?>" class="btn btn-xs btn-info"><?php echo app('translator')->getFromJson('quickadmin.qa_edit'); ?></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('recepcionmercaderium_delete')): ?>
                                    <?php echo Form::open(array(
                                        'style' => 'display: inline-block;',
                                        'method' => 'DELETE',
                                        'onsubmit' => "return confirm('".trans("quickadmin.qa_are_you_sure")."');",
                                        'route' => ['recepcionmercaderias.destroy', $recepcionmercaderia->id])); ?>

                                    <?php echo Form::submit(trans('quickadmin.qa_delete'), array('class' => 'btn btn-xs btn-danger')); ?>

                                    <?php echo Form::close(); ?>

                                    <?php endif; ?>
                                </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td colspan="10"><?php echo app('translator')->getFromJson('quickadmin.qa_no_entries_in_table'); ?></td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
</div>
<div role="tabpanel" class="tab-pane " id="facturas">
<table class="table table-bordered table-striped <?php echo e(count($facturas) > 0 ? 'datatable' : ''); ?>">
    <thead>
        <tr>
            <th><?php echo app('translator')->getFromJson('quickadmin.facturas.fields.folio'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.facturas.fields.vendedor'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.facturas.fields.fecha'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.facturas.fields.cliente'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.facturas.fields.producto'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.facturas.fields.cantidad'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.facturas.fields.precio'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.facturas.fields.condicion-pago'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.facturas.fields.estado-pago'); ?></th>
                        <th><?php echo app('translator')->getFromJson('quickadmin.facturas.fields.documento-valido'); ?></th>
                        <th>&nbsp;</th>
        </tr>
    </thead>

    <tbody>
        <?php if(count($facturas) > 0): ?>
            <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr data-entry-id="<?php echo e($factura->id); ?>">
                    <td><?php echo e($factura->folio); ?></td>
                                <td><?php echo e(isset($factura->vendedor->name) ? $factura->vendedor->name : ''); ?></td>
                                <td><?php echo e($factura->fecha); ?></td>
                                <td><?php echo e(isset($factura->cliente->nombre) ? $factura->cliente->nombre : ''); ?></td>
                                <td><?php echo e(isset($factura->producto->nombre) ? $factura->producto->nombre : ''); ?></td>
                                <td><?php echo e($factura->cantidad); ?></td>
                                <td><?php echo e($factura->precio); ?></td>
                                <td><?php echo e($factura->condicion_pago); ?></td>
                                <td><?php echo e(Form::checkbox("estado_pago", 1, $factura->estado_pago == 1, ["disabled"])); ?></td>
                                <td><?php echo e(Form::checkbox("documento_valido", 1, $factura->documento_valido == 1, ["disabled"])); ?></td>
                                <td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('factura_view')): ?>
                                    <a href="<?php echo e(route('facturas.show',[$factura->id])); ?>" class="btn btn-xs btn-primary"><?php echo app('translator')->getFromJson('quickadmin.qa_view'); ?></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('factura_edit')): ?>
                                    <a href="<?php echo e(route('facturas.edit',[$factura->id])); ?>" class="btn btn-xs btn-info"><?php echo app('translator')->getFromJson('quickadmin.qa_edit'); ?></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('factura_delete')): ?>
                                    <?php echo Form::open(array(
                                        'style' => 'display: inline-block;',
                                        'method' => 'DELETE',
                                        'onsubmit' => "return confirm('".trans("quickadmin.qa_are_you_sure")."');",
                                        'route' => ['facturas.destroy', $factura->id])); ?>

                                    <?php echo Form::submit(trans('quickadmin.qa_delete'), array('class' => 'btn btn-xs btn-danger')); ?>

                                    <?php echo Form::close(); ?>

                                    <?php endif; ?>
                                </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td colspan="14"><?php echo app('translator')->getFromJson('quickadmin.qa_no_entries_in_table'); ?></td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
</div>
</div>

            <p>&nbsp;</p>

            <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-default"><?php echo app('translator')->getFromJson('quickadmin.qa_back_to_list'); ?></a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>