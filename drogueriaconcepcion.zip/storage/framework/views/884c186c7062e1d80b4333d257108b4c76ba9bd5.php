<?php $__env->startSection('content'); ?>
    <h3 class="page-title"><?php echo app('translator')->getFromJson('quickadmin.proveedoroc.title'); ?></h3>
    
    <?php echo Form::model($proveedoroc, ['method' => 'PUT', 'route' => ['proveedorocs.update', $proveedoroc->id]]); ?>


    <div class="panel panel-default">
        <div class="panel-heading">
            <?php echo app('translator')->getFromJson('quickadmin.qa_edit'); ?>
        </div>

        <div class="panel-body">
            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('folio', 'Folio*', ['class' => 'control-label']); ?>

                    <?php echo Form::number('folio', old('folio'), ['class' => 'form-control', 'placeholder' => '']); ?>

                    <p class="help-block"></p>
                    <?php if($errors->has('folio')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('folio')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('proveedor_id', 'Proveedor*', ['class' => 'control-label']); ?>

                    <?php echo Form::select('proveedor_id', $proveedors, old('proveedor_id'), ['class' => 'form-control select2']); ?>

                    <p class="help-block"></p>
                    <?php if($errors->has('proveedor_id')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('proveedor_id')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('fecha', 'Fecha*', ['class' => 'control-label']); ?>

                    <?php echo Form::text('fecha', old('fecha'), ['class' => 'form-control date', 'placeholder' => '']); ?>

                    <p class="help-block"></p>
                    <?php if($errors->has('fecha')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('fecha')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('observaciones', 'Observaciones', ['class' => 'control-label']); ?>

                    <?php echo Form::textarea('observaciones', old('observaciones'), ['class' => 'form-control ', 'placeholder' => '']); ?>

                    <p class="help-block"></p>
                    <?php if($errors->has('observaciones')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('observaciones')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            
        </div>
    </div>

    <?php echo Form::submit(trans('quickadmin.qa_update'), ['class' => 'btn btn-danger']); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    ##parent-placeholder-b6e13ad53d8ec41b034c49f131c64e99cf25207a##
    <script>
        $('.date').datepicker({
            autoclose: true,
            dateFormat: "<?php echo e(config('app.date_format_js')); ?>"
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>